import pandas as pd
import numpy as np
import psycopg2
from psycopg2.extras import execute_values
 
def update_existing_rows_from_csv(
    csv_file_path: str,
    db_config: dict,
    table_name: str = "appendix_b_p2_conversion"
):
    # Define the table columns
    columns = [
        "hazardous_situation_id",
        "critical_qualitative",
        "moderate_qualitative",
        "minor_qualitative",
        "critical_semi_quantitative",
        "moderate_semi_quantitative",
        "minor_semi_quantitative",
        "probability_of_hazardous_situation_p1",
        "critical",
        "moderate",
        "minor",
        "critical_pharm_qualitative",
        "moderate_pharm_qualitative",
        "minor_pharm_qualitative"
    ]
 
    numeric_cols = [
        "critical_semi_quantitative",
        "moderate_semi_quantitative",
        "minor_semi_quantitative",
        "probability_of_hazardous_situation_p1",
        "critical",
        "moderate",
        "minor"
    ]
 
    try:
        df = pd.read_csv(csv_file_path)
        df = df[columns]  # filter to expected columns
 
        # Clean bad numeric entries
        df[numeric_cols] = df[numeric_cols].replace(
            ["NUL", "NULL", "NaN", "", "nan", " "], np.nan
        )
 
        for col in numeric_cols:
            df[col] = pd.to_numeric(df[col], errors='coerce')
 
    except Exception as e:
        print(f"❌ Error reading or cleaning CSV: {e}")
        return
 
    try:
        conn = psycopg2.connect(**db_config)
        cur = conn.cursor()
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        return
 
    # Convert DataFrame rows to list of tuples
    data = [tuple(row) for row in df.to_numpy()]
 
    # Build the UPDATE FROM query
    update_query = f"""
    INSERT INTO {table_name} ({', '.join(columns)})
    VALUES %s
    ON CONFLICT (hazardous_situation_id) DO UPDATE SET
    {', '.join([f'{col} = EXCLUDED.{col}' for col in columns if col != 'hazardous_situation_id'])};
"""
 
    try:
        execute_values(cur, update_query, data)
        conn.commit()
        print("✅ Existing rows updated successfully.")
    except Exception as e:
        print(f"❌ Error during update: {e}")
        conn.rollback()
    finally:
        cur.close()
        conn.close()
def db_update():
    csv_path = "Appendix_B.csv"
    
    db_config = {
        'dbname': 'baxterdb',        # Replace with your database name
        'user': 'baxterdev',        # Replace with your username
        'password': 'Password123',# Replace with your password
        'host': 'localhost',        # Use IP or host if not local
        'port': '5432'
    }
    
    update_existing_rows_from_csv(csv_path, db_config)

if __name__ == "__main__":
    db_update()