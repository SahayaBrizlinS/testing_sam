from fastapi import FastAPI
from table_creation import content_creation
from table_conversion1 import conversion
from Update_table import update_appendix_b_from_csv
 
app = FastAPI()
 
@app.get("/process")
def process_route():
    #content_creation()
    db_config = {

        'dbname': 'baxterdb',

        'user': 'baxterdev',

        'password': 'Password123',

        'host': 'localhost',

        'port': '5432'

    }
    conversion()
    update_appendix_b_from_csv('Appendix_B.csv', db_config)

